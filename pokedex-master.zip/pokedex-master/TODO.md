# TODO

* Show an error if the Pokémon doesn't exist

* Implement Pokémon Card as a Custom Directive

* Implement dynamic title like 'Pokédex | Bulbasaur' (hint: $rootScope y ng-bind)

* Change TabsController to use $scope and implement isActive function to remove the logic in the template

* Order comments by date, new comments must go first

* Implement a search form by name (with automatic preview)

* Show avatar in comments (hint: you can use gravatar filter in angular-md5 module)

* Implement a rating system and create a TOP 10 Pokémons by Rating (hint: you can use angular-ui / ui-bootstrap)

* Implement a service to interact with a REST API instead of local storage and use a real database (hint: you can use $resource)
